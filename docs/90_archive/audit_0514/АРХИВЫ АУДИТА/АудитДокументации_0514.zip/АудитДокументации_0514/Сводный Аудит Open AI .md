## Сводный отчет по технологиям и софту EPIOS

### 1. Общий вывод

По четырем аудитам EPIOS выглядит как **архитектурно сильный, но организационно и delivery-wise не до конца стабилизированный проект**. Все аудиты сходятся в том, что ядро выбрано правильно: structured reasoning, evidence-backed artifacts, traceability, human-in-the-loop, PostgreSQL-first, DDD, Hexagonal Architecture и MCP security boundary. При этом главные риски лежат не в выборе технологий, а в несоответствии между заявленным статусом “MVP RC” и фактическим состоянием контрактов, security tests, release evidence, документации и delivery governance. 

---

## 2. Ключевые технологии и подходы

| Технология / подход                        | Что это                                                                                | Роль в EPIOS                                                                                           | Текущее состояние                                                                                           | Рекомендация                                                                                           |
| ------------------------------------------ | -------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------ | ----------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------ |
| **EPIOS / Epistemic Operating System**     | Операционный слой для структурированного рассуждения, доказательств и принятия решений | Центральная продуктовая концепция: `situation → distinction → evidence → artifact → decision → action` | Концепция сильная, но продуктовая зрелость переобещана через статус RC                                      | Позиционировать как alpha / architecture validation до появления release evidence                      |
| **Structured Reasoning**                   | Формализация рассуждений в виде явных шагов, узлов, доказательств и решений            | Делает систему не просто чат-интерфейсом, а платформой для проверяемого мышления                       | Хорошо описано концептуально                                                                                | Перевести в исполняемые сценарии, fixtures и acceptance tests                                          |
| **Evidence-backed artifacts**              | Артефакты, связанные с доказательствами и источниками                                  | Основа доверия к результатам ИИ и человеческих решений                                                 | Архитектурно заявлено верно                                                                                 | Нужны trace catalog, evidence schema, redaction policy                                                 |
| **Human-in-the-loop**                      | Человек утверждает или отклоняет критические действия ИИ                               | Защищает систему от неконтролируемых side effects                                                      | В ряде документов выглядит слишком жестко: ручное подтверждение каждого утверждения может стать bottleneck  | Заменить на progressive governance: trust score, quarantine, consensus, review только критичных ветвей |
| **Progressive Governance / Trust Scoring** | Модель взвешенного доверия вместо тотального ручного контроля                          | Масштабирует работу с графом знаний и утверждениями ИИ                                                 | Рекомендовано в аудитах, но не оформлено как доменное правило                                               | Ввести уровни доверия `low / medium / high`, правила автопринятия и ретроспективного отзыва            |
| **Knowledge Graph / Docs-as-Graph**        | Представление задач, ADR, сценариев и решений как связанных узлов                      | Позволяет самой системе EPIOS управлять собственной документацией                                      | Пока документация в основном Markdown-driven                                                                | Перевести roadmap, ADR, backlog и сценарии в графовую модель проекта                                   |
| **Reasoning Provenance**                   | Отслеживание происхождения каждого вывода, действия или артефакта                      | Критично для доверия, аудита и воспроизводимости решений                                               | Заявлено как философия проекта                                                                              | Добавить неизменяемую историю изменений, подписи, audit trail                                          |

---

## 3. Архитектура и доменная модель

| Технология / подход                             | Что это                                                                      | Роль в EPIOS                                                                         | Текущее состояние                                                                                                  | Рекомендация                                                                    |
| ----------------------------------------------- | ---------------------------------------------------------------------------- | ------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------------------------------------------ | ------------------------------------------------------------------------------- |
| **Domain-Driven Design / DDD**                  | Проектирование вокруг предметной области, сущностей, инвариантов и use cases | Дает EPIOS сильное доменное ядро: Mission, EpistemicNode, ArtifactPatch, EvidenceRef | Все аудиты считают DDD сильной стороной проекта                                                                    | Зафиксировать domain invariants в тестах и контрактах                           |
| **Hexagonal Architecture / Ports & Adapters**   | Архитектура, где домен изолирован от инфраструктуры через порты и адаптеры   | Защищает ядро от зависимости от UI, БД, провайдеров ИИ и внешних SDK                 | Заявлена, но местами структура монорепозитория выглядит как обычный Turborepo без явного выделения ports/adapters  | Явно отразить ports/adapters в пакетах, dependency rules и CI                   |
| **Domain-free-of-infra**                        | Доменный слой не импортирует инфраструктуру, UI, БД, SDK и env               | Ключевой архитектурный инвариант                                                     | Описано, но без гарантированного dependency-check в CI есть риск нарушения                                         | Сделать dependency-cruiser required CI check                                    |
| **CQRS**                                        | Разделение командной и read-моделей                                          | Полезно для MissionReadModel, UI-слоев и аналитических представлений                 | Рекомендовано как улучшение, пока не core requirement                                                              | Добавлять после стабилизации MVP contracts                                      |
| **Event Sourcing readiness**                    | Хранение последовательности событий вместо только текущего состояния         | Подходит для MissionRun, audit trail и provenance                                    | Рекомендовано как architectural readiness                                                                          | Не внедрять сразу полностью, но проектировать события и trace schema совместимо |
| **Local-first + криптографическая верификация** | Локальное владение данными плюс подпись графов знаний / истории              | Усиливает доверие к evidence-backed artifacts                                        | Рекомендовано в Google-аудите как future direction                                                                 | Рассматривать как долгосрочную архитектурную цель, не как MVP-блокер            |

---

## 4. Backend, runtime и данные

| Технология / софт       | Что это                                                   | Роль в EPIOS                                                                        | Текущее состояние                                                       | Рекомендация                                                                |
| ----------------------- | --------------------------------------------------------- | ----------------------------------------------------------------------------------- | ----------------------------------------------------------------------- | --------------------------------------------------------------------------- |
| **TypeScript**          | Язык основного кода                                       | Единая типизация домена, API, UI и инфраструктуры                                   | Указан как часть стека                                                  | Использовать strict mode, shared schemas, generated types                   |
| **Node.js**             | Runtime для backend/tooling                               | Основа серверной части, CLI, scripts, CI                                            | Есть mismatch: README говорит Node v20+, package требует Node >=22.0.0  | Выбрать Node 22 как baseline и синхронизировать README, `.node-version`, CI |
| **PostgreSQL 17**       | Реляционная БД                                            | Источник истины для Mission, Evidence, ArtifactPatch, ApprovalRequest               | PostgreSQL-first признан правильным hard constraint                     | Добавить миграции, repository integration tests, optimistic concurrency     |
| **Zod / OpenAPI**       | Схемы валидации и API-контракты                           | Должны стать executable source of truth для DTO, ошибок, idempotency и trace events | Контракты пока недостаточно исполняемые                                 | Создать `API_CONTRACTS_MVP.md`, OpenAPI/Zod schemas и contract tests        |
| **Idempotency rules**   | Повтор команды не должен создавать дубли/побочные эффекты | Критично для approval flow, patch apply, MCP actions                                | Упоминается как требуемая часть security/domain checks                  | Вынести в контракт и покрыть тестами                                        |
| **Trace Event Catalog** | Каталог событий наблюдаемости и аудита                    | Нужен для traceability, release evidence, security audit                            | Отсутствие trace catalog отмечено как P1/P0 проблема                    | Создать `TRACE_EVENT_CATALOG.md` и схему событий                            |
| **Error Catalog**       | Единый каталог ошибок                                     | Делает API и use cases предсказуемыми                                               | Отсутствует как executable spec                                         | Создать `ERROR_CATALOG.md` с кодами, условиями, retryability                |

---

## 5. Frontend и пользовательский слой

| Технология / софт  | Что это                                                    | Роль в EPIOS                                                     | Текущее состояние                                     | Рекомендация                                                 |
| ------------------ | ---------------------------------------------------------- | ---------------------------------------------------------------- | ----------------------------------------------------- | ------------------------------------------------------------ |
| **React**          | UI-библиотека                                              | Основа shell/interface для работы с графами, миссиями, approvals | Указан в стеке как React/Vite                         | UI должен быть renderer, а не владельцем бизнес-правил       |
| **Vite**           | Frontend build tool                                        | Быстрая разработка demo-shell                                    | Указан в стеке                                        | Сохранить для dev velocity                                   |
| **UI as renderer** | UI только отображает состояние и отправляет typed commands | Защищает доменную логику от расползания по frontend              | Указано как правильный hard constraint                | Проверять через architecture tests                           |
| **Storybook**      | Каталог UI-компонентов и интерактивных примеров            | Полезен для документации компонентов и UX acceptance             | Рекомендован Qwen-аудитом как долгосрочное улучшение  | Внедрять после стабилизации core flows                       |
| **Mermaid**        | Текстовые диаграммы                                        | Подходит для C4, workflow, domain diagrams в docs                | Рекомендован для интерактивной документации           | Добавить диаграммы Mission flow, Approval flow, MCP boundary |

---

## 6. MCP, AI-интеграции и безопасность

| Технология / подход              | Что это                                                             | Роль в EPIOS                                                      | Текущее состояние                                     | Рекомендация                                                                            |
| -------------------------------- | ------------------------------------------------------------------- | ----------------------------------------------------------------- | ----------------------------------------------------- | --------------------------------------------------------------------------------------- |
| **MCP / Model Context Protocol** | Протокол интеграции моделей/агентов с контекстом и инструментами    | Позволяет подключать AI-assisted actions и интерактивные MCP Apps | MCP security boundary признан сильной стороной        | Довести до исполняемых security tests                                                   |
| **MCP Apps as untrusted iframe** | MCP UI рассматривается как недоверенная поверхность                 | Предотвращает прямые мутации домена из iframe                     | Указано как правильный security boundary              | Запретить direct patch apply; только typed commands через bridge                        |
| **Bridge validation**            | Проверка origin, nonce, capability, schema                          | Защищает от spoofing, replay и privilege escalation               | Требуется EPIOS-06, но тесты выглядят незавершенными  | Реализовать тесты: invalid origin, replayed nonce, missing capability, schema rejection |
| **Continuous Agent Auditing**    | CI/CD-проверки поведения агентов и промптов                         | Нужно, чтобы изменения AGENT.md/MCP не ломали reasoning quality   | Рекомендовано Google-аудитом                          | Добавить agent eval smoke tests и сценарные regression tests                            |
| **AI-assisted Domain Modeling**  | Использование LLM для извлечения узлов, связей и черновиков моделей | Может ускорять построение графа знаний                            | Рекомендовано как улучшение                           | Использовать только через human review / trust scoring                                  |
| **Redaction Policy**             | Очистка логов/trace от секретов, токенов, персональных данных       | Критично для safe observability                                   | Отсутствие redaction policy отмечено как риск утечек  | Создать `DATA_RETENTION_AND_REDACTION_POLICY_MVP.md` и sanitizer tests                  |

---

## 7. Monorepo, сборка и разработка

| Технология / софт                     | Что это                                    | Роль в EPIOS                                                     | Текущее состояние                       | Рекомендация                                                    |
| ------------------------------------- | ------------------------------------------ | ---------------------------------------------------------------- | --------------------------------------- | --------------------------------------------------------------- |
| **pnpm**                              | Менеджер пакетов                           | Управление monorepo dependencies                                 | Указан как часть monorepo-стека         | Зафиксировать версию `packageManager`                           |
| **Turborepo / Turbo v2**              | Оркестрация задач в monorepo               | Ускоряет build/test/lint по пакетам                              | Указан как уже присутствующий tooling   | Сделать pipeline прозрачным: build, lint, test, depcruise, docs |
| **apps / packages / docs / fixtures** | Модульная структура репозитория            | Разделяет приложения, библиотеки, документацию и тестовые данные | Отмечено как сильная сторона структуры  | Дополнительно явно выделить ports/adapters                      |
| **Husky**                             | Git hooks                                  | Локальная проверка перед коммитом                                | Указан в составе tooling                | Использовать для lint, commitlint, docs checks                  |
| **lint-staged**                       | Запускает проверки только на staged-файлах | Ускоряет pre-commit проверки                                     | Указан среди появившихся инструментов   | Сохранять, но не заменять полноценный CI                        |
| **commitlint / conventional commits** | Проверка формата коммитов                  | Нужны для changelog/release notes                                | Указано как практика контроля качества  | Автоматизировать CHANGELOG и Release Drafter                    |

---

## 8. CI/CD, качество и delivery governance

| Технология / софт                           | Что это                                                                                   | Роль в EPIOS                                                     | Текущее состояние                                                                                    | Рекомендация                                                                  |
| ------------------------------------------- | ----------------------------------------------------------------------------------------- | ---------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------- |
| **GitHub Actions**                          | CI/CD-платформа                                                                           | Проверки build/test/lint/security/docs                           | Конфигурации есть, но есть риск несовпадения веток `master` vs `main`                                | Синхронизировать default branch и workflows                                   |
| **Protected branches / rulesets**           | Защита основной ветки                                                                     | Требует PR, checks, reviews, запрет direct push                  | Заявлено в process docs, но требует фактического включения                                           | Включить required checks: CI, gitleaks, depcruise, tests                      |
| **Trunk-based development**                 | Малые частые изменения в trunk                                                            | Уменьшает integration risk                                       | Рекомендовано для EPIOS как delivery через vertical slices                                           | Работать маленькими PR по одному mission flow                                 |
| **Architecture-Governed Vertical Delivery** | Каждый slice проходит contract → domain → persistence → API → trace → test → release gate | Лучше соответствует traceability-философии EPIOS                 | Прямо рекомендовано OpenAI-аудитом                                                                   | Сделать базовой моделью разработки                                            |
| **Release Gate Evidence Matrix**            | Матрица доказательств готовности релиза                                                   | Защищает от “release optimism”                                   | Отсутствует, из-за чего RC-статус выглядит преждевременным                                           | Создать матрицу gates, CI run links, tests, known limitations, owner approval |
| **Release Drafter**                         | Генерация release notes                                                                   | Автоматизирует релизный процесс                                  | Указан как уже появившийся tooling                                                                   | Связать с conventional commits, labels, milestones                            |
| **GitHub Issues / Milestones / Projects**   | Управление delivery                                                                       | Переводит roadmap из Markdown в управляемую систему задач        | Аудит отмечает несоответствие: docs требуют issues/milestones, но delivery выглядит markdown-driven  | Перенести Week 1–6 в GitHub milestones                                        |
| **Linear / ClickUp**                        | PM-инструменты                                                                            | Могут усилить velocity tracking и AI-assisted project management | Рекомендованы как опциональное улучшение                                                             | Использовать только если GitHub Projects недостаточно                         |

---

## 9. Тестирование

| Технология / софт             | Что это                                                    | Роль в EPIOS                                           | Текущее состояние                                                  | Рекомендация                                      |
| ----------------------------- | ---------------------------------------------------------- | ------------------------------------------------------ | ------------------------------------------------------------------ | ------------------------------------------------- |
| **Vitest**                    | Unit/integration test runner для TypeScript                | Проверка domain, application, utilities                | Указан среди текущего tooling                                      | Покрыть domain invariants, use cases, error paths |
| **Playwright**                | E2E/browser testing                                        | Проверка demo-shell и critical user flows              | Указан среди текущего tooling                                      | E2E smoke на mission flow и approval flow         |
| **MSW**                       | Mock Service Worker                                        | Моки API для frontend/integration tests                | Рекомендован Grok-аудитом                                          | Использовать для UI tests без реального backend   |
| **Testcontainers**            | Поднятие реальных зависимостей в тестах                    | PostgreSQL integration tests, migrations, repositories | Рекомендован как современная практика                              | Ввести для repository и migration tests           |
| **Security tests**            | Тесты MCP, authorization, nonce, capabilities, idempotency | Критично для безопасных AI-assisted actions            | Сейчас есть риск false-green: security script ничего не проверяет  | Сделать security tests обязательными перед RC     |
| **Scenario acceptance packs** | Наборы fixtures + expected nodes/evidence/patch/trace      | Проверяют продуктовые сценарии EPIOS                   | Рекомендованы как PR-10                                            | Один каталог на каждый MVP-сценарий               |

---

## 10. Документация и governance

| Технология / подход                       | Что это                                 | Роль в EPIOS                               | Текущее состояние                                                                                | Рекомендация                                                                 |
| ----------------------------------------- | --------------------------------------- | ------------------------------------------ | ------------------------------------------------------------------------------------------------ | ---------------------------------------------------------------------------- |
| **ADR / Architecture Decision Records**   | Файлы фиксации архитектурных решений    | Дают traceability по решениям              | Сильный подход, но были/есть проблемы с нумерацией, статусами и отсутствием реальных ADR-файлов  | Ввести clean ADR index, статусы, даты пересмотра, связанные решения          |
| **RFC process**                           | Процесс обсуждения крупных изменений    | Полезен для cross-cutting решений          | Рекомендован, но pipeline RFC → ADR не формализован                                              | Ввести RFC Tiering: lightweight/full, deadline, owner                        |
| **DOCUMENT_REGISTER.md**                  | Реестр документов                       | Управляет lifecycle документации           | В раннем аудите отсутствовал, позже частично стабилизирован                                      | Сделать обязательным источником истины                                       |
| **OPEN_DECISIONS_REGISTER.md**            | Реестр открытых решений                 | Показывает нерешенные governance-вопросы   | Отмечен как core control document                                                                | Поддерживать вместе с ADR                                                    |
| **Docs-as-Code**                          | Документация как код, проходящий CI     | Делает docs проверяемыми и версионируемыми | Рекомендовано всеми аудитами в разных формах                                                     | Markdownlint, link checker, spell checker, docs preview                      |
| **MkDocs / Docusaurus**                   | Сайты документации                      | Поиск, навигация, versioned docs           | Рекомендовано Qwen-аудитом                                                                       | Выбрать один инструмент; для dev-docs лучше MkDocs Material или Docusaurus   |
| **GitBook / Mintlify**                    | SaaS/платформы для документации         | Красивые public docs и Git sync            | Рекомендованы Grok-аудитом                                                                       | Подходят для public-facing docs                                              |
| **Obsidian**                              | Локальная knowledge base                | Может помочь internal knowledge graph      | Рекомендован как internal knowledge tool                                                         | Использовать только как вспомогательный инструмент, не source of truth       |
| **AI-assisted documentation maintenance** | LLM проверяет актуальность docs по коду | Ускоряет обновление документации           | Рекомендовано Qwen-аудитом                                                                       | Использовать для черновиков CHANGELOG, ADR suggestions, stale docs detection |
| **CHANGELOG.md**                          | История изменений                       | Нужен для релизов и доверия к версиям      | Отсутствие CHANGELOG отмечено как недочет                                                        | Автогенерировать из conventional commits                                     |

---

## 11. Security и supply chain

| Технология / софт                              | Что это                                         | Роль в EPIOS                       | Текущее состояние                             | Рекомендация                                          |
| ---------------------------------------------- | ----------------------------------------------- | ---------------------------------- | --------------------------------------------- | ----------------------------------------------------- |
| **Gitleaks**                                   | Поиск секретов в репозитории                    | Защита от утечек токенов и ключей  | Указан как уже появившийся tooling            | Сделать required CI check                             |
| **Trivy**                                      | Сканер уязвимостей контейнеров/dependencies/IaC | Supply-chain security              | Рекомендован Grok-аудитом                     | Добавить в CI security baseline                       |
| **GitGuardian**                                | Secret scanning                                 | Альтернатива/дополнение к Gitleaks | Рекомендован как современная практика         | Использовать при наличии бюджета/интеграции           |
| **Dependabot / Renovate**                      | Автообновление зависимостей                     | Снижает dependency risk            | Рекомендованы в нескольких аудитах            | Выбрать один; для monorepo часто удобен Renovate      |
| **SBOM**                                       | Software Bill of Materials                      | Список компонентов релиза          | Рекомендован как часть supply-chain baseline  | Генерировать для релизов                              |
| **Artifact attestations**                      | Подтверждения происхождения build artifacts     | Усиливает доверие к релизам        | Рекомендовано OpenAI-аудитом                  | Добавить для release builds                           |
| **Least privilege GitHub Actions permissions** | Минимальные права для CI jobs                   | Уменьшает blast radius             | Рекомендовано как Secure SDLC baseline        | Установить `permissions: contents: read` по умолчанию |

---

## 12. Observability и эксплуатация

| Технология / софт               | Что это                              | Роль в EPIOS                                    | Текущее состояние                                       | Рекомендация                                                                  |
| ------------------------------- | ------------------------------------ | ----------------------------------------------- | ------------------------------------------------------- | ----------------------------------------------------------------------------- |
| **OpenTelemetry**               | Стандарт трассировки, метрик и логов | Основа наблюдаемости Mission flow и AI actions  | Рекомендован Grok-аудитом                               | Ввести после trace event catalog                                              |
| **Tempo / Grafana**             | Хранилище traces и визуализация      | Анализ выполнения сценариев, ошибок, latency    | Рекомендованы как observability stack                   | Для MVP достаточно минимального OTel + Grafana dashboard                      |
| **DORA dashboard**              | Метрики delivery performance         | Помогает управлять velocity и качеством релизов | Рекомендован как P2 улучшение                           | Вводить после стабилизации GitHub Issues/Milestones                           |
| **Production Deployment Guide** | Руководство по запуску в production  | Нужно для корпоративного внедрения              | Qwen-аудит отмечает отсутствие production/scaling docs  | Добавить `docker-compose.prod.yml`, env policy, backup/restore, scaling notes |
| **docker-compose.prod.yml**     | Пример production-like конфигурации  | Упрощает пилоты и enterprise adoption           | Отсутствует как пример конфигурации                     | Добавить после определения deployment target                                  |

---

## 13. Главные несоответствия, которые нужно закрыть первыми

1. **Статус RC не подтвержден evidence.** README/package заявляют `v0.1.0-rc.1`, но аудит указывает на отсутствие полноценного release evidence, GitHub release, linked milestone, test evidence и known limitations. 
2. **CI/default branch mismatch.** Документы и workflows ориентируются на `main`, а репозиторий/ссылки могут использовать `master`, что делает branch protection потенциально неэффективным. 
3. **Contract-first заявлен, но не доведен до executable specs.** Нужны API contracts, use case contracts, error catalog, trace event catalog и traceability matrix. 
4. **Security tests не должны быть false-green.** Заглушка `test:security`, которая завершает CI успешно, противоречит уровню безопасности, заявленному для MCP. 
5. **Документация сильная, но не стабилизирована как lifecycle.** Нужны реестры документов, clean ADR index, Open Decisions Register, Docs-as-Code checks и единый процесс обновления. 
6. **Human-in-the-loop требует масштабируемой модели.** Ручная валидация каждого утверждения плохо совместима с большими графами знаний; нужен progressive governance/trust scoring. 

---

## 14. Рекомендуемая целевая модель

Оптимальная модель для EPIOS — **Architecture-Governed Vertical Delivery**:

```text
Mission Slice
→ Contract
→ Domain invariant
→ Persistence migration
→ Application use case
→ Interface/API
→ Trace event
→ Security policy
→ Test evidence
→ Release gate
```

Эта модель лучше обычного roadmap/backlog, потому что сам продукт обещает traceability. Следовательно, процесс разработки тоже должен быть traceable: каждое изменение должно иметь контракт, доменный инвариант, ошибку, trace event, security rule, тест и release evidence. 

---

## 15. Приоритетный план внедрения

### P0 — до публичного позиционирования как RC

1. Синхронизировать `master/main`, branch protection и GitHub Actions.
2. Переименовать статус в `alpha/internal dev`, либо оформить настоящий RC с release evidence.
3. Убрать false-green security tests.
4. Создать contract pack:

   * `API_CONTRACTS_MVP.md`
   * `APPLICATION_USE_CASE_CONTRACTS.md`
   * `ERROR_CATALOG.md`
   * `TRACE_EVENT_CATALOG.md`
   * `TRACEABILITY_MATRIX_MVP.md`
5. Зафиксировать `SCENARIO_REGISTRY_MVP.md`.
6. Создать release gate evidence matrix.

### P1 — Week 1–2

1. Стабилизировать docs lifecycle:

   * `DOCUMENT_REGISTER.md`
   * `OPEN_DECISIONS_REGISTER.md`
   * clean ADR index
   * ADR statuses
2. Настроить docs CI:

   * markdownlint
   * link checker
   * spell checker RU/EN
   * OpenAPI/Zod schema validation
3. Ввести repository integration tests через Testcontainers.
4. Перенести backlog в GitHub Issues/Milestones.

### P2 — после стабилизации MVP

1. MkDocs/Docusaurus или GitBook/Mintlify.
2. Storybook для UI.
3. OpenTelemetry + Grafana/Tempo.
4. DORA dashboard.
5. Progressive governance / trust scoring.
6. Event Sourcing readiness и CQRS read models.
7. SBOM, artifact attestations, Renovate/Dependabot.

---

### Итог

Технологический стек EPIOS выбран в целом правильно: **TypeScript + Node + React/Vite + PostgreSQL + DDD + Hexagonal + MCP + GitHub-native delivery + Docs-as-Code** хорошо соответствует платформе для проверяемого reasoning. Основная проблема — не выбор технологий, а отсутствие достаточного количества **исполняемых доказательств зрелости**: контрактов, security tests, release gates, актуальных docs checks и синхронизированного delivery-процесса.
